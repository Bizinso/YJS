<template>
    <div>
       <b-tabs class="masterTabs" content-class="masterTabContent">
            <b-tab title="First" active>
                <p>I'm the first tab</p>
            </b-tab>
            <b-tab title="Second">
                <p>I'm the second tab</p>
            </b-tab>
            <b-tab title="Third">
                <p>I'm the third tab</p>
            </b-tab>
            <b-tab title="Fourth">
                <p>I'm the fourth tab</p>
            </b-tab>
            <b-tab title="Fifth">
                <p>I'm the fifth tab</p>
            </b-tab>
            <b-tab title="Sixth">
                <p>I'm the sixth tab</p>
            </b-tab>
        </b-tabs>

    </div>
</template>
<script>
export default {
}
</script>

