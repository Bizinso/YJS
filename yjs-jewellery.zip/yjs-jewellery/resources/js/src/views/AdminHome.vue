<template>
    <div>
        <h2>Admin Dashboard</h2>
    </div>
</template>