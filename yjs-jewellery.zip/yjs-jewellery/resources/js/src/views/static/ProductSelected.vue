<script setup>
</script>
<template>
    <div class="yjs_product">
        <div class="global_breadcrumbs">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="/partner/products">Our Products</a></li>
                    <li>Earring</li>
                </ul>
            </div>
        </div>
        <div class="boxHeader OrangeBox">
            <div class="container cardBox">
                <div class="infoBase">
                    <h2 class="globalHeading">01. EARRING</h2>
                    <p class="basicDetails">Earrings are one of the primary form of the jewelry found throughout the history.It's jewellery to show your love and commitment for your loved one.</p>
                    <div class="linkingBTN">
                        <button class="buttonSelector">View all products</button>
                        <button class="buttonSelector"><img src="../assets/images/static/product/download.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
                <img src="../assets/images/static/product/earringsBanner.png" alt="ring1" class="namingBanner" />
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}"  class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>

        

        
    </div>
</template>