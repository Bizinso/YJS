<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InventoryLogController extends Controller
{
    //
}
