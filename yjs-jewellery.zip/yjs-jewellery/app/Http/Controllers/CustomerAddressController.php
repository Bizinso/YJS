<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerAddressController extends Controller
{
    //
}
