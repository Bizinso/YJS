<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SizeMaster extends Model
{
    //
}
