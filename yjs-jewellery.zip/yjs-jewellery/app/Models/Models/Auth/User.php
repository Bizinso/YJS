<?php

namespace App\Models\Models\Auth;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    //
}
