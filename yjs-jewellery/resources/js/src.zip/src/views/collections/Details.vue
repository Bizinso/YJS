<script setup>
</script>
<template>
    <div class="yjs_collections">
        <div class="global_breadcrumbs">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li>Italy</li>
                </ul>
            </div>
        </div>
         <div class="details_launches">
            <div class="container">
                <img src="../assets/images/collections/collections_banner.png" alt="ll1" class="mainImage" />
            </div>
        </div>

         <!-- Latest Launches -->
        <div class="details_launches">
            <div class="container">
                <h2>Celestial Glow</h2>
                <p class="basicDetails">The Celestial Glow Collection is a tribute to the infinite beauty of the night sky, where every star tells a story of brilliance. Crafted in luminous gold and set with radiant diamonds and rare gemstones, each piece mirrors the shimmer of constellations and the mystery of galaxies. With fluid lines and delicate detailing, the collection evokes the magic of starlight captured in timeless jewelry design.</p>
                <p class="basicDetails">Inspired by the celestial dance of the cosmos, this collection blends artistry with elegance to create treasures that transcend trends. From cascading necklaces that echo the Milky Way to constellation-inspired rings that sparkle with cosmic charm, Celestial Glow is designed for those who carry their own light. It is more than jewelry — it is a celebration of radiance, wonder, and eternal allure.</p>
                    
            </div>
        </div>

        <div class="productTabSegregation">
            <div class="container">

                    <b-tabs >
                        <b-tab title="Rings" active>
                            <div class="productImageGrid">
                                <div class="verticalGrid">
                                    <img src="../assets/images/collections/collection-details/ring1.png" alt="ring1" class="mainImage" />
                                    <img src="../assets/images/collections/collection-details/ring2.png" alt="ring2" class="mainImage" />
                                </div>
                                <div class="horizontalGrid">
                                    <img src="../assets/images/collections/collection-details/ring3.png" alt="ring3" class="mainImage" />
                                </div> 
                            </div>
                        </b-tab>
                        <b-tab title="Necklaces">
                            <div class="productImageGrid">
                                <div class="verticalGrid">
                                    <img src="../assets/images/collections/collection-details/ring1.png" alt="ring1" class="mainImage" />
                                    <img src="../assets/images/collections/collection-details/ring2.png" alt="ring2" class="mainImage" />
                                </div>
                                <div class="horizontalGrid">
                                    <img src="../assets/images/collections/collection-details/ring3.png" alt="ring3" class="mainImage" />
                                </div> 
                            </div>
                        </b-tab>
                        <b-tab title="Earrings">
                            <div class="productImageGrid">
                                <div class="verticalGrid">
                                    <img src="../assets/images/collections/collection-details/ring1.png" alt="ring1" class="mainImage" />
                                    <img src="../assets/images/collections/collection-details/ring2.png" alt="ring2" class="mainImage" />
                                </div>
                                <div class="horizontalGrid">
                                    <img src="../assets/images/collections/collection-details/ring3.png" alt="ring3" class="mainImage" />
                                </div> 
                            </div>
                        </b-tab>
                    </b-tabs>
        </div>    
        </div>


    </div>
</template>