<script setup>
</script>
<template>
    <div class="yjs_collections">
        <!-- banner -->
        <div class="collections_banner py-5">
            <div class="collections_banner_info">
                <h1 class="mb-1">Eternal Radiance Collection</h1>
                <p>A celebration of timeless brilliance, crafted for the modern muse.</p>
            </div>
        </div>

         <!-- Latest Launches -->
        <div class="latest_launches py-5">
            <div class="container">
                <h2>Latest Launches</h2>
                <p>Be the first to discover our newest creations, where artistry meets luxury.</p>
                <div class="latest_launches_grid mt-4">
                    <div class="latest_launches_item">
                        <img src="../assets/images/collections/latest-launches/ll1.png" alt="ll1" />
                        <h5 class="mt-3 mb-1">Celestial Glow</h5>
                        <p class="mb-2">Inspired by starlit skies, this collection captures the elegance of the cosmos.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="latest_launches_item">
                        <img src="../assets/images/collections/latest-launches/ll2.png" alt="ll2" />
                        <h5 class="mt-3 mb-1">Royal Heritage</h5>
                        <p class="mb-2">A tribute to regal artistry, blending antique charm with modern finesse.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                </div>
            </div>
        </div>

        <!-- Explore by Year -->
        <div class="explore_by_year py-5">
            <div class="container">
                <h2>Explore by Year</h2>
                <p class="mb-4">Travel through time and revisit the artistry of our past collections.</p>
                <div class="separator">Year 2025</div>
                <div class="explore_by_year_grid mt-3">
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby1.png" alt="eby1" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby2.png" alt="eby2" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby3.png" alt="eby3" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby1.png" alt="eby1" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby2.png" alt="eby2" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                    <div class="explore_by_year_item mb-3">
                        <div class="explore_by_year_pic">
                            <img src="../assets/images/explore_by_year/eby3.png" alt="eby3" />
                            <span>Launch Date: August 2025</span>
                        </div>
                        <h5 class="mt-3 mb-1">Ocean Whisper</h5>
                        <p class="mb-2">Inspired by the rhythm of waves and serenity of the sea.</p>
                        <b-link :to="{name: 'details'}">View Details <img src="../assets/images/icons/right-arrow-black.svg" alt="right-arrow-black"></b-link>
                    </div>
                </div>
            </div>
        </div>


    </div>
</template>