<script setup>
</script>
<template>
    <div class="yjs_product">
        <div class="boxHeader OrangeBox">
            <div class="container cardBox">
                <div class="infoBase">
                    <h2 class="globalHeading">01. EARRING</h2>
                    <p class="basicDetails">Earrings are one of the primary form of the jewelry found throughout the history.It's jewellery to show your love and commitment for your loved one.</p>
                    <div class="linkingBTN">
                        <b-link :to="{name: 'productsSelected'}" class="buttonSelector">View all products</b-link>
                        <button class="buttonSelector"><img src="../assets/images/static/product/download.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
                <img src="../assets/images/static/product/earringsBanner.png" alt="ring1" class="namingBanner" />
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/earrings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>

        

        <div class="boxHeader BlueBox">
            <div class="container cardBox">
                <img src="../assets/images/static/product/ringsBanner.png" alt="ring1" class="namingBanner" />
                <div class="infoBase">
                    <h2 class="globalHeading">02. RING</h2>
                    <p class="basicDetails">Rings is brighton,every piece of ring is created around you .Ring are symbol of love and something you buy for your loved and special once.</p>
                    <div class="linkingBTN">
                        <a class="buttonSelector" href="/productsSelected">View all products</a>
                        <button class="buttonSelector"><img src="../assets/images/static/product/downloadwhite.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/rings4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>

        

        <div class="boxHeader OrangeBox">
            <div class="container cardBox">
                <div class="infoBase">
                    <h2 class="globalHeading">03. MANGALSUTRA</h2>
                    <p class="basicDetails">Mangalsutra menas, It's a sacred thread .The managalsutra is an important piece of jewellery worn by indian married woman.It symbolizes eternal love and marriage.</p>
                    <div class="linkingBTN">
                        <a class="buttonSelector" href="/productsSelected">View all products</a>
                        <button class="buttonSelector"><img src="../assets/images/static/product/download.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
                <img src="../assets/images/static/product/mangalsutraBanner.png" alt="ring1" class="namingBanner" />
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/mangalsutra4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>



        

        <div class="boxHeader BlueBox">
            <div class="container cardBox">
                <img src="../assets/images/static/product/braceletesBanner.png" alt="ring1" class="namingBanner" />
                <div class="infoBase">
                    <h2 class="globalHeading">04. BRACELETES</h2>
                    <p class="basicDetails">A bracelet is an article of jewellery that is worn around the wrist. Bracelets may serve different uses, such as being worn as an ornament.</p>
                    <div class="linkingBTN">
                        <a class="buttonSelector" href="/productsSelected">View all products</a>
                        <button class="buttonSelector"><img src="../assets/images/static/product/downloadwhite.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/braceletes4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>



        

        <div class="boxHeader OrangeBox">
            <div class="container cardBox">
                <div class="infoBase">
                    <h2 class="globalHeading">05. KADAS</h2>
                    <p class="basicDetails">Kada is a thick metal ring usually wore in hands by men and women of Indian sub-continent, Mostly made of silver or gold. Kada has different design styles and was used to show honor towards someone by offering them Kada.</p>
                    <div class="linkingBTN">
                        <a class="buttonSelector" href="/productsSelected">View all products</a>
                        <button class="buttonSelector"><img src="../assets/images/static/product/download.svg" alt="Download" class="iconBox">Download Brochure</button>
                    </div>
                </div>
                <img src="../assets/images/static/product/kadasBanner.png" alt="ring1" class="namingBanner" />
            </div>
        </div>
        <div class="container">

            <div class="productlist">
                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-001</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-002</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-003</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-004</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas1.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-005</p>
                </b-link>


                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas2.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-006</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas3.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p>EPRO-007</p>
                </b-link>

                <b-link :to="{name: 'productsDetails'}" class="productItem">
                    <div class="productImage">
                        <img src="../assets/images/static/product/kadas4.png" alt="ring1" class="banner" />
                        <div class="productIcons">
                            <i class="fa-regular fa-heart"></i>
                            <i class="fa-regular fa-eye"></i>
                        </div>
                    </div>
                    <p class="productName">EPRO-008</p>
                </b-link>
            </div>
            
        </div>

    </div>
</template>