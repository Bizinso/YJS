<script setup>
</script>
<template>
    <div>
        <h2>Dashboard</h2>
    </div>
</template>