<script setup>
</script>
<template>
    <div>
        <h2>Masters</h2>
    </div>
</template>